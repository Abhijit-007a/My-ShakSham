import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class10Chem.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class6-7Chem.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class8-9Chem.dart';

class ChemistryPage extends StatefulWidget {
  @override
  _ChemistryPageState createState() => _ChemistryPageState();
}

class _ChemistryPageState extends State<ChemistryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.class_),
        title: const Text('Class'),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.white24,
      body: ListView(
        children: <Widget>[
          SizedBox(height: 30.0),
          Class67Chem(),
          Class89Chem(),
          Class10Chem(),
          Padding(
            padding: const EdgeInsets.only(top:50,left: 80,right: 80),
            child: Text("--- More courses comming soon ! ---", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
          )
        ],
      ),
    );
  }
}