import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Biology.dart';
import 'package:login_minimalist/SubjectCards/Chemistry.dart';
import 'package:login_minimalist/SubjectCards/Mathematics.dart';
import 'package:login_minimalist/SubjectCards/Physics.dart';
import 'package:login_minimalist/widgets/CustomMenuBar.dart';
import 'package:login_minimalist/widgets/SearchButton.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {

  @override
  Widget build(BuildContext context) {

    final width =MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white24,
      body: ListView(
        children: <Widget>[
          _top(),
          SizedBox(height: 0.0),
          Physics(),
          Chemistry(),
          Biology(),
          Mathematics(),
          SearchButton(),
        ],
      ),
    );
  }


  _top(){
    return Container(
      padding: EdgeInsets.all(10.0),
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [Colors.black, Colors.black38]),
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(30.0),
            bottomRight: Radius.circular(30.0),
          )
      ),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[

              Row(
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.account_circle, color: Colors.white60,),
                    onPressed: (){
                      Navigator.of(context).pushNamed('/convertUser');
                    },
                  ),
                  SizedBox(width: 70.0),
                  Text("My ShakSham",style: TextStyle(color: Colors.white,fontSize: 21, letterSpacing: 5,))
                ],
              ),
              IconButton(
                icon: Icon(Icons.star, color: Colors.white60,),
                onPressed: (){

                },
              ),
            ],
          ),
          SizedBox(height: 20.0),
          CustomAppBar(),
        ],
      ),
    );
  }
}