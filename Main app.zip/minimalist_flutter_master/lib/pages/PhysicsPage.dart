import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class10Phy.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class6-7Phy.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class8-9Phy.dart';


class PhysicsPage extends StatefulWidget {
  @override
  _PhysicsPageState createState() => _PhysicsPageState();
}

class _PhysicsPageState extends State<PhysicsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.class_),
        title: const Text('Class'),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.white24,
      body: ListView(
        children: <Widget>[
          SizedBox(height: 30.0),
          Class67Phy(),
          Class89Phy(),
          Class10Phy(),
          Padding(
            padding: const EdgeInsets.only(top:50,left: 80,right: 80),
            child: Text("--- More courses comming soon ! ---", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
          )
        ],
      ),
    );
  }
}