import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class10Bio.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class6-7Bio.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class8-9Bio.dart';



class BiologyPage extends StatefulWidget {
  @override
  _BiologyPageState createState() => _BiologyPageState();
}

class _BiologyPageState extends State<BiologyPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white24,
      appBar: AppBar(
        leading: Icon(Icons.class_),
        title: const Text('Class'),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        children: <Widget>[
          SizedBox(height: 30.0),
          Class67Bio(),
          Class89Bio(),
          Class10Bio(),
          Padding(
            padding: const EdgeInsets.only(top:50,left: 80,right: 80),
            child: Text("--- More courses comming soon ! ---", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
          )

        ],
      ),
    );
  }
  }