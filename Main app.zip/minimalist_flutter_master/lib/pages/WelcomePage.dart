import 'package:flutter/material.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/services.dart';
import 'package:login_minimalist/pages/Dashboard.dart';
import 'package:login_minimalist/widgets/WelcomePageSignIn.dart';

class WelcomePage extends StatelessWidget {
  final primaryColor =const Color(0xFF28313B);


  @override
  Widget build(BuildContext context) {
    final width =MediaQuery.of(context).size.width;
    final height =MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.orangeAccent,
      body: Container(

        width: width,
        height: 590,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/welcome.gif"),

            fit: BoxFit.contain,
            //centerSlice: new Rect.fromLTRB(0.0, 0.0, 0.0, 0.0),



          ),
        ),
        child: SafeArea(
          child: Padding(
              padding: const EdgeInsets.only(top:300.0),

              child: Column(
                children: <Widget>[


                  //AutoSizeText("Let's achieve your Goal ", maxLines: 2, textAlign: TextAlign.center, style: TextStyle(fontSize: 35, color: Colors.white),),
                  SizedBox(
                      height: height * 0.15
                  ),
                  RaisedButton(
                    color: Colors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0)),
                    child:Padding(
                      padding: const EdgeInsets.only(top: 10.0, bottom: 10.0, left: 30.0, right: 30.0),

                      child: Text("Get Started", style: TextStyle(color: Colors.white, fontSize: 23.0, fontWeight: FontWeight.w500),),
                    ),
                    onPressed: (){
                      showDialog(
                          context: context,
                          builder: (BuildContext context) => WelcomePageSignIn(
                            title: "Would you like to create a free account?",
                            description: "with an account,your data will be securely saved",
                            primaryButtonText: "Create My Account" ,
                            primaryButtonRoute:"/signUp" ,
                            secondaryButtonText: "May be later" ,
                            secondaryButtonRoute:"/anonymousSignIn" ,

                          )
                      );
                    },
                  ),
                  SizedBox(
                      height: height * 0.02
                  ),
                  FlatButton(
                    child: Text("Sign In" , style: TextStyle(color: Colors.white, fontSize: 20),),
                    onPressed: (){
                      Navigator.of(context).pushReplacementNamed('/signIn');
                    },
                  )
                ],

              )
          ),
        ),
      ),
    );
  }
}