import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class10Maths.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class6-7Maths.dart';
import 'package:login_minimalist/SubjectCards/Classes/Class8-9Maths.dart';


class MathematicsPage extends StatefulWidget {
  @override
  _MathematicsPageState createState() => _MathematicsPageState();
}

class _MathematicsPageState extends State<MathematicsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.class_),
        title: const Text('Class'),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.white24,
      body: ListView(
        children: <Widget>[
          SizedBox(height: 30.0),
          Class67Maths(),
          Class89Maths(),
          Class10Maths(),
          Padding(
            padding: const EdgeInsets.only(top:50,left: 80,right: 80),
            child: Text("--- More courses comming soon ! ---", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
          )
        ],
      ),
    );
  }
}