import 'package:flutter/material.dart';
import 'package:login_minimalist/main.dart';
import 'package:login_minimalist/pages/WelcomePage.dart';
import 'package:splashscreen/splashscreen.dart';


class Spa extends StatefulWidget {
  @override
  _SpaState createState() => new _SpaState();
}

class _SpaState extends State<Spa> {
  @override
  Widget build(BuildContext context) {
    return new SplashScreen(

      seconds: 5,
      navigateAfterSeconds: HomeController(),
      image: new Image.asset('assets/loading.gif', width: 300.0, height: 300.0),
      backgroundColor: Colors.white,
      styleTextUnderTheLoader: new TextStyle(),
      photoSize: 150.0,

      loaderColor: Colors.black,
    );
  }
}