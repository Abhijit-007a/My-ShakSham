

import 'package:flutter/material.dart';

class Planet {
  final String id;
  final String name;
  final String description;
  final String image;

  const Planet({this.id, this.name,
    this.description, this.image});
}

List<Planet> planets = [
   Planet(
    id: "1",
    name: "My Profile",
    description: "Personal Description",
    image: "assets/profile.png",


  ),
  const Planet(
    id: "3",
    name: "Statistics",
    description: "Measures Performances",
    image: "assets/statistics.png",
  ),
  const Planet(
    id: "4",
    name: "Settings",
    description: "Personalise",
    image: "assets/settings.png",
  ),
  const Planet(
    id: "5",
    name: "Help & Feedback",
    description: "Customer Service",
    image: "assets/feedback.png",
  ),
  const Planet(
    id: "6",
    name: "Version 0.0.1",
    description: "About",
    image: "assets/version.png",
  ),
];