import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:auto_size_text/auto_size_text.dart';

class WelcomePageSignIn extends StatelessWidget {
  final primaryColor =const Color(0xffD2A813
  );
  final greyColor =const Color(0xFF939393);
  final String title, description,primaryButtonText ,primaryButtonRoute, secondaryButtonText ,secondaryButtonRoute;

  WelcomePageSignIn({
    @required this.title,
    @required this.description,
    @required this.primaryButtonText,
    @required this.primaryButtonRoute,
    this.secondaryButtonText,
    this.secondaryButtonRoute

  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0),),
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15.0),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [
                    const Color(0xff000000),
                    const Color(0xff000000
                    )
                  ],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(1.0, 0.0),
                  stops: [0.0, 1.0],
                  tileMode: TileMode.clamp
              ),
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(30.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black,
                  blurRadius: 10.0,
                  offset: const Offset(0.0, 10.0),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SizedBox(height: 24.0),
                AutoSizeText(title, maxLines: 2, textAlign: TextAlign.center,style: TextStyle( color: Colors.white,fontSize: 25.0,),
                ),
                SizedBox(height: 24.0),
                AutoSizeText(description, maxLines: 4, textAlign: TextAlign.center,style: TextStyle( color: greyColor,fontSize: 18.0,),
                ),
                SizedBox(height: 24.0),
                RaisedButton(
                  color: primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0)),
                  child: AutoSizeText(
                    primaryButtonText,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w200,
                      color: Colors.white,
                    ),
                  ),
                  onPressed: (){
                    Navigator.of(context).pop();
                    Navigator.of(context).pushReplacementNamed(primaryButtonRoute);
                  },
                ),
                SizedBox(height: 24.0),
                showSecondaryButton(context),
              ],
            ),
          )
        ],
      ),

    );
  }

  showSecondaryButton(BuildContext context) {
    if(secondaryButtonRoute != null && secondaryButtonText != null ){
      return FlatButton(
        child: AutoSizeText(secondaryButtonText, maxLines: 1, style: TextStyle(fontSize: 18.0, color: primaryColor, fontWeight: FontWeight.w400,),
        ),
        onPressed: () {
          Navigator.of(context).pop();
          Navigator.of(context).pushReplacementNamed(secondaryButtonRoute);
        },
      );
    }else{
      return SizedBox(height: 10.0,);
    }

  }
}