import 'package:flutter/material.dart';
import 'package:login_minimalist/home/MenuDrawer.dart';
import 'package:login_minimalist/pages/Dashboard.dart';

class CustomAppBar extends StatefulWidget {
  @override
  _CustomAppBarState createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 0, left: 20, right:20, bottom: 10),
      child: Container(
        alignment: Alignment.topCenter,
        height: 40,
        width:180,
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.white12,
                blurRadius: 20.0, // has the effect of softening the shadow
                spreadRadius: 5.0, // has the effect of extending the shadow
                offset: Offset(
                  5.0, // horizontal, move right 10
                  5.0, // vertical, move down 10
                ),
              ),
            ],
            color: Colors.black, borderRadius: BorderRadius.circular(30)),
        child: FlatButton(
          padding: EdgeInsets.all(0),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => MenuDrawer()));
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Icon(
                Icons.dashboard,
                color: Colors.blueGrey,
              ),
            ],
          ),
        ),
      ),
    );
  }
}