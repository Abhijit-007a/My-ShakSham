import 'package:flutter/material.dart';

class Statistics extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      backgroundColor: Colors.white24,
      appBar: AppBar(
        title: Text("My Statistics"),
        backgroundColor: Colors.black,
      ),
       body: ListView(
           children: <Widget>[
             Padding(
               padding: const EdgeInsets.only(top:350,left: 80,right: 80),
               child: Text("We are very soon going to introduce this feature by the mid of August. Stay tuned !", style: TextStyle(fontSize: 17.4,fontWeight: FontWeight.bold,color: Colors.yellow),),
             ),
             ],
      ),
    );
  }
}
