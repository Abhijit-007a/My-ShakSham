import 'package:flutter/material.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color(0xff000000),
        body: SafeArea(
          child: new SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                CircleAvatar(
                    radius: 70, backgroundImage: AssetImage('assets/images/pritish.jpg')),
                Text(
                  'Pritish Prusty',
                  style: TextStyle(
                      fontFamily: 'name',
                      color: Color(0xfff07b3f),
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  'App Developer',
                  style: TextStyle(
                      fontFamily: 'SourceSansPro',
                      letterSpacing: 2.5,
                      color: Color(0xfff07b3f),
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                SizedBox(
                  height: 25,
                  width: 150,
                  child: Divider(
                    color: Color(0xfff07b3f),
                  ),
                ),
                Card(
                  margin: EdgeInsets.symmetric(vertical: 0,horizontal: 25),
                  child: ListTile(
                    leading: Icon(
                      Icons.link,
                      color: Color(0xfff07b3f),
                    ),
                    title: Text(
                      'https://www.linkedin.com/in/pritishprusty/',
                      style: TextStyle(
                        fontFamily: 'SourceSansPro',
                        color: Color(0xfff07b3f),
                        fontSize: 20,
                      ),
                    ),
                  ),

                ),
                Card(

                  margin: EdgeInsets.symmetric(vertical: 20,horizontal: 25),
                  child: ListTile(
                    leading: Icon(
                      Icons.email,
                      color: Color(0xfff07b3f),

                    ),
                    title: Text(
                      'priashprusty07@gmail.com',
                      style: TextStyle(
                        fontFamily: 'SourceSansPro',
                        color: Color(0xfff07b3f),
                        fontSize: 20,
                      ),
                    ),
                  ),

                ),
                CircleAvatar(
                    radius: 70, backgroundImage: AssetImage('assets/images/abhijit.jpg')),

                Text(
                  'Abhjit Biswas',
                  style: TextStyle(
                      fontFamily: 'name',
                      color: Color(0xfff07b3f),
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  'App  Developer',
                  style: TextStyle(
                      fontFamily: 'SourceSansPro',
                      letterSpacing: 2.5,
                      color: Color(0xfff07b3f),
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                SizedBox(
                  height: 25,
                  width: 150,
                  child: Divider(
                    color: Color(0xfff07b3f),
                  ),
                ),
                Card(
                  margin: EdgeInsets.symmetric(vertical: 10,horizontal: 25),
                  child: ListTile(
                    leading: Icon(
                      Icons.link,
                      color: Color(0xfff07b3f),
                    ),
                    title: Text(
                      'https://www.linkedin.com/in/abhijit-biswas-862634167/',
                      style: TextStyle(
                        fontFamily: 'SourceSansPro',
                        color: Color(0xfff07b3f),
                        fontSize: 20,
                      ),
                    ),
                  ),

                ),
                Card(
                  margin: EdgeInsets.symmetric(vertical: 13,horizontal: 25),
                  child: ListTile(
                    leading: Icon(
                      Icons.email,
                      color: Color(0xfff07b3f),
                    ),
                    title: Text(
                      'biswasavhijit007@gmail.com',
                      style: TextStyle(
                        fontFamily: 'SourceSansPro',
                        color: Color(0xfff07b3f),
                        fontSize: 20,
                      ),
                    ),
                  ),

                ),
                SizedBox(height: 20.0,),
                Text(
                  'Version 0.0.1',
                  style: TextStyle(
                      fontFamily: 'SourceSansPro',
                      letterSpacing: 2.5,
                      color: Color(0xfff07b3f),
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),
                ),
                SizedBox(height: 30.0,),
              ],
            ),
          ),
        ),
      ),
    );
  }
}