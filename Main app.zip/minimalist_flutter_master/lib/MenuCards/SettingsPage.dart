import 'package:flutter/material.dart';
import 'package:login_minimalist/home/MenuDrawer.dart';
import 'package:login_minimalist/pages/WelcomePage.dart';
import 'package:login_minimalist/service_firebase/auth_service.dart';
import 'package:login_minimalist/widgets/Provider_widget.dart';

class SettingsTwoPage extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(


        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios, color: Colors.white60,),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) =>
                                MenuDrawer()));
                      },
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Settings",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),

                SwitchListTile(

                  title: Text(
                    "Email Notifications",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "On",
                    style: greyTExt,
                  ),
                  value: true,
                  onChanged: (val) {},
                ),
                SwitchListTile(
                  title: Text(
                    "Push Notifications",
                    style: greyTExt,
                    //style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Off",
                    style: greyTExt,
                  ),
                  value: false,
                  onChanged: (val) {},
                ),
                ListTile(
                  title: Text(
                    "Logout",
                    style: greyTExt,

                    //style: whiteBoldText,
                  ),
                  onTap: () async {
                    try {
                      AuthService auth = Provider
                          .of(context)
                          .auth;
                      await auth.signOut();
                      print("signedOut");
                    } catch (e) {
                      print(e);
                    }
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => WelcomePage()));
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}