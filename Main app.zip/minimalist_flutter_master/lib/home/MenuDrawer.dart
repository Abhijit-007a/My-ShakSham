import 'package:flutter/material.dart';
import 'package:login_minimalist/home/MenuDrawerBody.dart';
import 'package:login_minimalist/pages/Dashboard.dart';

class MenuDrawer extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
       appBar: AppBar(
         leading: Icon(Icons.arrow_back_ios),
          title: Padding(
            padding: const EdgeInsets.only(left: 110.0),
            child: const Text('Menu', style: TextStyle(color: Colors.white,letterSpacing: 4),),
          ),
         backgroundColor: Colors.black,
       ),
      body: new Column(
        children: <Widget>[

          new MenuDrawerBody(),
        ],
      ),
    );
  }
}

class GradientAppBar extends StatelessWidget {

  final String title;
  final double barHeight = 50.0;

  GradientAppBar(this.title);

  @override
  Widget build(BuildContext context) {

    final double statusBarHeight = MediaQuery
        .of(context)
        .padding
        .top;

    return new Container(
      padding: new EdgeInsets.only(top: statusBarHeight),
      height: statusBarHeight + barHeight,
      child: new Center(
        child: new Text(title,
          style:const TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              fontSize: 23.0
          ),
        ),
      ),
      decoration: new BoxDecoration(
        gradient: new LinearGradient(
            colors: [
              const Color(0xff000000),
              const Color(0xff000000)
            ],
            begin: const FractionalOffset(0.0, 0.0),
            end: const FractionalOffset(1.0, 0.0),
            stops: [0.0, 1.0],
            tileMode: TileMode.clamp
        ),
      ),
    );
  }
}