import 'package:flutter/material.dart';
import 'package:login_minimalist/MenuCards/About.dart';
import 'package:login_minimalist/MenuCards/Help&Feedback.dart';
import 'package:login_minimalist/MenuCards/ProfilePage.dart';
import 'package:login_minimalist/MenuCards/SettingsPage.dart';
import 'package:login_minimalist/MenuCards/StatisticsPage.dart';
import 'package:login_minimalist/pages/Splash.dart';
import 'package:login_minimalist/service_firebase/auth_service.dart';
import 'package:login_minimalist/pages/Dashboard.dart';
import 'package:login_minimalist/pages/SignUpPage.dart';
import 'package:login_minimalist/pages/WelcomePage.dart';
import 'package:login_minimalist/widgets/Provider_widget.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer1.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer2.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer3.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer4.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer5.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer6.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer7.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer8.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer9.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer10.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer11.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer12.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer13.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer14.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer15.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer16.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer17.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer18.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer19.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer20.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer21.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer22.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer23.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer24.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer25.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer26.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer27.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer28.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer29.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer30.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer31.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer32.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer33.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer34.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer35.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer36.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer37.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer38.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer39.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer40.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer42.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer43.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer44.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer45.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer46.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer47.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer48.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer49.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer50.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer51.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer52.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer53.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer54.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer55.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer56.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer57.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer58.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer59.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer60.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer61.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer62.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer63.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer64.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer65.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer66.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer67.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer68.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer69.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer70.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer71.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer72.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer73.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer74.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer75.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer76.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer77.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer78.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer79.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer80.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer81.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer82.dart';
import 'package:login_minimalist/pdfviewer/PDFviewer83.dart';


void main() => runApp(Sps());

class Sps extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Provider(
      auth: AuthService(),
      child: MaterialApp(
          title: 'My ShakSham',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            fontFamily: 'Poppins',

          ),
          home: Spa(),
          debugShowCheckedModeBanner: false,
          routes: <String, WidgetBuilder> {
            '/home' :(BuildContext context) => HomeController(),
            '/signUp' :(BuildContext context) => SignUpView(authFormType: AuthFormType.signUp),
            '/signIn' :(BuildContext context) => SignUpView(authFormType: AuthFormType.signIn),
            '/anonymousSignIn' :(BuildContext context) => SignUpView(authFormType: AuthFormType.anonymous),
            '/convertUser':(BuildContext context) => SignUpView(authFormType: AuthFormType.convert),
            '1':(BuildContext context) => Profile(),
            '3':(BuildContext context) => Statistics(),
            '4':(BuildContext context) => SettingsTwoPage(),
            '5':(BuildContext context) => FormThree(),
            '6':(BuildContext context) => About(),
            '/logout':(BuildContext context) => WelcomePage(),
            'eyecolour':(BuildContext context) => Viewer1(),
            'Electricity':(BuildContext context) => Viewer2(),
            'Magnetic_current':(BuildContext context) => Viewer3(),
            'SourceofEnergy':(BuildContext context) => Viewer4(),
            'metalnonmetals':(BuildContext context) => Viewer5(),
            'lifeProcess':(BuildContext context) => Viewer6(),
            'chemicalReac':(BuildContext context) => Viewer7(),
            'Light':(BuildContext context) => Viewer8(),
            'OurEnvironment':(BuildContext context) => Viewer9(),
            'NaturalResources':(BuildContext context) => Viewer10(),
            'Carbon':(BuildContext context) => Viewer11(),
            'AcidBasesalt':(BuildContext context) => Viewer12(),
            'Elements':(BuildContext context) => Viewer13(),
            'Coordination':(BuildContext context) => Viewer14(),
            'Repro':(BuildContext context) => Viewer15(),
            'Heridity':(BuildContext context) => Viewer16(),
            'Matter':(BuildContext context) => Viewer17(),
            'Gravitation':(BuildContext context) => Viewer18(),
            'Work':(BuildContext context) => Viewer19(),
            'Sound':(BuildContext context) => Viewer20(),
            'Ill':(BuildContext context) => Viewer21(),
            'Natural':(BuildContext context) => Viewer22(),
            'FoodResources':(BuildContext context) => Viewer23(),
            'Pure':(BuildContext context) => Viewer24(),
            'Particals':(BuildContext context) => Viewer25(),
            'Atoms':(BuildContext context) => Viewer26(),
            'Cell':(BuildContext context) => Viewer27(),
            'Tissue':(BuildContext context) => Viewer28(),
            'Diversity':(BuildContext context) => Viewer29(),
            'Motion':(BuildContext context) => Viewer30(),
            'Force':(BuildContext context) => Viewer31(),
            'Pressure':(BuildContext context) => Viewer32(),
            'Friction':(BuildContext context) => Viewer33(),
            'Sound':(BuildContext context) => Viewer34(),
            'Effects of Electric Current':(BuildContext context) => Viewer35(),
            'Light':(BuildContext context) => Viewer36(),
            '	Synthetic Fibres and Plastics':(BuildContext context) => Viewer37(),
            'Materials: Metals and Non-Metals':(BuildContext context) => Viewer38(),
            'Coal':(BuildContext context) => Viewer39(),
            'Combustion':(BuildContext context) => Viewer40(),
            'crop':(BuildContext context) => Viewer42(),
            'micro':(BuildContext context) => Viewer43(),
            'conerv':(BuildContext context) => Viewer44(),
            'cell':(BuildContext context) => Viewer45(),
            'reproduce':(BuildContext context) => Viewer46(),
            'adolescence':(BuildContext context) => Viewer47(),
            'naturalpheno':(BuildContext context) => Viewer48(),
            'poluution':(BuildContext context) => Viewer49(),
            'motion':(BuildContext context) => Viewer50(),
            'electric':(BuildContext context) => Viewer51(),
            'light':(BuildContext context) => Viewer52(),
            'fibrefabric':(BuildContext context) => Viewer53(),
            'heat':(BuildContext context) => Viewer54(),
            'acidbases':(BuildContext context) => Viewer55(),
            'phychem':(BuildContext context) => Viewer56(),
            'nutriPlants':(BuildContext context) => Viewer57(),
            'forest':(BuildContext context) => Viewer58(),
            'wastewater':(BuildContext context) => Viewer59(),
            'Nutrition':(BuildContext context) => Viewer60(),
            'weather':(BuildContext context) => Viewer61(),
            'windsstorm':(BuildContext context) => Viewer62(),
            'soil':(BuildContext context) => Viewer63(),
            'resporga':(BuildContext context) => Viewer64(),
            'transportplant':(BuildContext context) => Viewer65(),
            'reprodection':(BuildContext context) => Viewer66(),
            'waterprecious':(BuildContext context) => Viewer67(),
            'water':(BuildContext context) => Viewer68(),
            'airarus':(BuildContext context) => Viewer69(),
            'garbage':(BuildContext context) => Viewer70(),
            'motionmesure':(BuildContext context) => Viewer71(),
            'lightshadow':(BuildContext context) => Viewer72(),
            'eleccirc':(BuildContext context) => Viewer73(),
            'funmagnet':(BuildContext context) => Viewer74(),
            'compfood':(BuildContext context) => Viewer75(),
            'fibrefab':(BuildContext context) => Viewer76(),
            'sorting':(BuildContext context) => Viewer77(),
            'sepratesub':(BuildContext context) => Viewer78(),
            'changesarus':(BuildContext context) => Viewer79(),
            'getnoplants':(BuildContext context) => Viewer80(),
            'bodymove':(BuildContext context) => Viewer81(),
            'livingorg':(BuildContext context) => Viewer82(),
            'foodclass6':(BuildContext context) => Viewer83(),


          }
      ),
    );
  }
}


class HomeController extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final AuthService auth = Provider.of(context).auth;
    return StreamBuilder<String>(
      stream: auth.onAuthStateChanged,
      builder: (context, AsyncSnapshot<String> snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          final bool signedIn = snapshot.hasData;
          return signedIn ? Dashboard() : WelcomePage();
        }
        return CircularProgressIndicator();
      },
    );
  }
}


