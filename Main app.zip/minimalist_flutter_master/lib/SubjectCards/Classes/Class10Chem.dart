
import 'package:flutter/material.dart';
import 'package:login_minimalist/SubjectCards/Classes/Chapters/Chemistry/Class10ChemChapters.dart';

/// This Widget is the main application widget.
class Class10Chem extends StatelessWidget {


  @override
  Widget build(BuildContext context) {

    double width = MediaQuery.of(context).size.width;

    return Center(

      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(

          mainAxisSize: MainAxisSize.min,
          children: <Widget>[

            const SizedBox(height: 10,width: 10,),
            RaisedButton(
              padding: const EdgeInsets.all(0.0),
              color: Colors.transparent,
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Class10ChemCh()));
              },
              textColor: Colors.white,

              child: Container(
                alignment: Alignment.topLeft,
                height: 200,
                width:width * 0.85,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/class10.gif"),

                    fit: BoxFit.cover,
                    //centerSlice: new Rect.fromLTRB(0.0, 0.0, 0.0, 0.0),



                  ),

                  borderRadius: BorderRadius.circular(20),
                ),
                padding: const EdgeInsets.only(left:150.0,right: 40,top: 30,bottom: 50),
                child:
                const Text('Class X ', style: TextStyle(fontSize: 20,fontFamily: 'Poppins',fontWeight: FontWeight.w500,letterSpacing: 2)
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
