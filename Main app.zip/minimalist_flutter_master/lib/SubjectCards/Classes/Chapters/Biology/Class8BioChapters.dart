import 'package:flutter/material.dart';
import 'package:login_minimalist/pages/BiologyPage.dart';

class Class8BioCh extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(
        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios, color: Colors.white60,),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) =>
                                BiologyPage()));
                      },
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Class: 8",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                          Text(
                            "Biology",
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),


                ListTile(

                  title: Text(
                    "Chapter: 1",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Crop Production and Management",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'crop');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 2",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Components of Food",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 3",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Microorganisms: Friend and Foe",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'micro');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 4",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Cell — Structure and Functions",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'cell');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 5",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Reproduction in Animals",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'reproduce');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 6",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Reaching the Age of Adolescence",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'adolescence');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 7",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Pollution of Air and Water",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'poluution');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 8",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Some Natural Phenomena",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'naturalpheno');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 9",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Conervation of plants and animals",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'conerv');

                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
