import 'package:flutter/material.dart';
import 'package:login_minimalist/pages/BiologyPage.dart';

class Class7BioCh extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(
        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios, color: Colors.white60,),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) =>
                                BiologyPage()));
                      },
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Class: 7",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                          Text(
                            "Biology",
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),

                ListTile(

                  title: Text(
                    "Chapter: 1",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Nutrition in Plants",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'nutriPlants');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 2",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Nutrition in Animals",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'Nutrition');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 3",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Weather, Climate and Adaptations of Animals to Climate",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'weather');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 4",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Winds, Storms and Cyclones",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'windsstorm');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 5",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " Soil",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'soil');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 6",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Respiration in Organisms",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'resporga');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 7",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Transportation in Animals and Plants",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'transportplant');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 8",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Reproduction in Plants",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'reprodection');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 9",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Water: A Precious Resource",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'waterprecious');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 10",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " Forests: Our Lifeline",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'forest');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 11",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Waste Water Story",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'wastewater');

                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
