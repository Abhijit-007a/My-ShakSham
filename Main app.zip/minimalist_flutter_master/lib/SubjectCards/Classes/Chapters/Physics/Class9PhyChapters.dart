import 'package:flutter/material.dart';
import 'package:login_minimalist/pages/BiologyPage.dart';
import 'package:login_minimalist/pages/PhysicsPage.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class Class9PhyCh extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(
        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(MdiIcons.telescope, color: Colors.white60,),
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Class: 9",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                          Text(
                            "Physics",
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),

                ListTile(

                  title: Text(
                    "Chapter: 1",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Motion",
                    style: greyTExt,
                  ),
                  onTap: () {
                    Navigator.pushNamed(context, 'Motion');
                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 2",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Force and Newton's laws",
                    style: greyTExt,
                  ),
                  onTap: () {
                    Navigator.pushNamed(context, 'Force');
                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 3",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Gravitation",
                    style: greyTExt,
                  ),
                  onTap: () {
                    Navigator.pushNamed(context, 'Gravitation');
                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 5",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Work, energy and power",
                    style: greyTExt,
                  ),
                  onTap: () {
                    Navigator.pushNamed(context, 'Work');
                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 6",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Sound",
                    style: greyTExt,
                  ),
                  onTap: () {
                    Navigator.pushNamed(context, 'Sound');
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
