import 'package:flutter/material.dart';
import 'package:login_minimalist/pages/MathematicsPage.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class Class8MathsCh extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(
        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(MdiIcons.mathCompass, color: Colors.white60,),
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Class: 8",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                          Text(
                            "Mathematics",
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),

                ListTile(

                  title: Text(
                    "Chapter: 1",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Rational Numbers",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 2",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Linear Equations in One Variable",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 3",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Understanding Quadrilaterals",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 4",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Practical Geometry",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 5",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Data Handling",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 6",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Squares and Square Roots",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 7",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Cubes and Cube Roots",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 8",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Comparing Quantities",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 9",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Algebraic Expressions and Identities",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 10",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Visualizing Solid Shapes",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 11",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Mensuration",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 12",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Exponents and Powers",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 13",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Direct and Inverse Proportions",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 14",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Factorization",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 15",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    " 	Introduction to Graphs",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 16",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Playing with Numbers",
                    style: greyTExt,
                  ),
                  onTap: () {

                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
