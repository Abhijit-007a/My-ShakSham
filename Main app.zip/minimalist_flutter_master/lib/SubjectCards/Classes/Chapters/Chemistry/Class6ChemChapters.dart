import 'package:flutter/material.dart';
import 'package:login_minimalist/pages/BiologyPage.dart';

class Class6ChemCh extends StatelessWidget {


  static final String path = "lib/src/pages/settings/settings2.dart";
  final TextStyle whiteText = TextStyle(
    color: Colors.white,
  );
  final TextStyle greyTExt = TextStyle(
    color: Colors.grey.shade400,
  );
  @override
  Widget build(BuildContext context) {
    final _height = MediaQuery
        .of(context)
        .size
        .height;
    final _width = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(

      backgroundColor: Colors.black,
      body: Theme(
        data: Theme.of(context).copyWith(
          brightness: Brightness.dark,
          primaryColor: Colors.purple,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32.0),
            child: Column(


              children: <Widget>[
                const SizedBox(height: 30.0),
                Row(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.arrow_back_ios, color: Colors.white60,),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) =>
                                BiologyPage()));
                      },
                    ),

                    Container(


                    ),
                    const SizedBox(width: 10.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "Class: 6",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20.0,
                            ),
                          ),
                          Text(
                            "Chemistry",
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20.0),

                ListTile(

                  title: Text(
                    "Chapter: 1",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Fibre to Fabric",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'fibrefab');

                  },
                  ),
                ListTile(

                  title: Text(
                    "Chapter: 2",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Sorting Materials into Groups",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'sorting');

                    },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 3",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Separation of Substances",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'sepratesub');
                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 4",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Changes Around Us",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'changesarus');

                  },
                ),
                ListTile(

                  title: Text(
                    "Chapter: 5",
                    style: greyTExt,
                    // style: whiteBoldText,
                  ),
                  subtitle: Text(
                    "Air Around Us",
                    style: greyTExt,
                  ),
                  onTap: () {  Navigator.pushNamed(context, 'airarus');

                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
