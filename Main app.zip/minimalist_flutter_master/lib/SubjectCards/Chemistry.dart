import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:login_minimalist/pages/ChemistryPage.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class Chemistry extends StatefulWidget {
  @override
  _ChemistryState createState() => _ChemistryState();
}

class _ChemistryState extends State<Chemistry> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/welcome1.gif"),

            fit: BoxFit.cover,
            //centerSlice: new Rect.fromLTRB(0.0, 0.0, 0.0, 0.0),



          ),

          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const ListTile(
              leading: Icon(MdiIcons.flask,size: 40,color: Colors.white,),

              title: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text('Chemistry', style: TextStyle(fontWeight: FontWeight.w500,fontSize: 30, color: Colors.yellow,letterSpacing: 2),),
              ),

              subtitle: Text('Chemistry is the science that deals with the composition and properties of substances and various elementary forms of matter. ', style: TextStyle(fontWeight: FontWeight.bold,fontSize: 13, color: Colors.white),),
            ),
            RaisedButton(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30.0)),
              color: Colors.transparent,
              child: const Text('GO',style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white,),),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ChemistryPage()));
              },
            ),
          ],
        ),
      ),
    );
  }
}