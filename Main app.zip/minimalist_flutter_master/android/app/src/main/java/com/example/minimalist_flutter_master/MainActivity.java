package com.example.minimalist_flutter_master;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
